
import argparse
from dataclasses import dataclass
from typing import Tuple

import numpy as np
import pandas as pd
from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
import matplotlib.pyplot as plt


@dataclass
class PCAResults:
    X_pca: np.ndarray
    y: np.ndarray
    explained_variance_ratio_: np.ndarray
    feature_names: list


def load_and_prepare_data() -> Tuple[np.ndarray, np.ndarray, list]:
    data = datasets.load_breast_cancer()
    X = data.data
    y = data.target
    feature_names = list(data.feature_names)
    return X, y, feature_names


def run_pca(n_components: int = 2) -> PCAResults:
    X, y, feature_names = load_and_prepare_data()

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    pca = PCA(n_components=n_components, random_state=42)
    X_pca = pca.fit_transform(X_scaled)

    return PCAResults(
        X_pca=X_pca,
        y=y,
        explained_variance_ratio_=pca.explained_variance_ratio_,
        feature_names=feature_names,
    )


def train_logreg(X_train, X_test, y_train, y_test, random_state: int = 42, use_balanced=False):
    clf = LogisticRegression(max_iter=1000, random_state=random_state, class_weight="balanced" if use_balanced else None)
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred)
    return acc, report


def save_plots(results: PCAResults, out_dir: str):
    # Scree plot for explained variance
    plt.figure()
    xs = np.arange(1, len(results.explained_variance_ratio_) + 1)
    plt.bar(xs, results.explained_variance_ratio_)
    plt.xticks(xs)
    plt.xlabel("Principal Component")
    plt.ylabel("Explained Variance Ratio")
    plt.title("PCA Scree Plot (First {} Components)".format(len(xs)))
    scree_path = f"{out_dir}/scree_plot.png"
    plt.tight_layout()
    plt.savefig(scree_path, dpi=180)
    plt.close()

    # 2D scatter of first two components
    if results.X_pca.shape[1] >= 2:
        plt.figure()
        mask0 = results.y == 0
        mask1 = results.y == 1
        plt.scatter(results.X_pca[mask0, 0], results.X_pca[mask0, 1], label="Class 0")
        plt.scatter(results.X_pca[mask1, 0], results.X_pca[mask1, 1], label="Class 1")
        plt.xlabel("PC1")
        plt.ylabel("PC2")
        plt.legend()
        plt.title("PCA (2 Components) Scatter")
        scatter_path = f"{out_dir}/pca_scatter.png"
        plt.tight_layout()
        plt.savefig(scatter_path, dpi=180)
        plt.close()
        return scree_path, scatter_path
    return scree_path, None


def main(args=None):
    parser = argparse.ArgumentParser(description="PCA + Logistic Regression on Breast Cancer Dataset")
    parser.add_argument("--components", type=int, default=2, help="Number of PCA components")
    parser.add_argument("--balanced", action="store_true", help="Use class_weight='balanced' for Logistic Regression")
    parser.add_argument("--outdir", type=str, default="outputs", help="Output directory")
    ns = parser.parse_args(args=args)

    out_dir = ns.outdir

    # Run PCA
    results = run_pca(n_components=ns.components)

    # Save PCA components to CSV
    df_pca = pd.DataFrame(results.X_pca, columns=[f"PC{i+1}" for i in range(results.X_pca.shape[1])])
    df_pca["target"] = results.y
    csv_path = f"{out_dir}/pca_components.csv"
    df_pca.to_csv(csv_path, index=False)

    # Plots
    scree_path, scatter_path = save_plots(results, out_dir)

    # Train/test split on PCA features (bonus)
    X_train, X_test, y_train, y_test = train_test_split(results.X_pca, results.y, test_size=0.25, random_state=42, stratify=results.y)
    acc_pca, report_pca = train_logreg(X_train, X_test, y_train, y_test, use_balanced=ns.balanced)

    # Also logistic regression on full standardized features for comparison
    X, y, _ = load_and_prepare_data()
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    X_train_f, X_test_f, y_train_f, y_test_f = train_test_split(X_scaled, y, test_size=0.25, random_state=42, stratify=y)
    acc_full, report_full = train_logreg(X_train_f, X_test_f, y_train_f, y_test_f, use_balanced=ns.balanced)

    print("=== PCA Summary ===")
    print("Explained variance ratio (first {} comps): {}".format(len(results.explained_variance_ratio_), results.explained_variance_ratio_))
    print(f"Scree plot saved to: {scree_path}")
    if scatter_path:
        print(f"PCA scatter saved to: {scatter_path}")
    print(f"PCA components CSV saved to: {csv_path}")

    print("\n=== Logistic Regression (on 2 PCA components) ===")
    print(f"Accuracy: {acc_pca:.4f}")
    print(report_pca)

    print("=== Logistic Regression (on full standardized features) ===")
    print(f"Accuracy: {acc_full:.4f}")
    print(report_full)


if __name__ == "__main__":
    main()
